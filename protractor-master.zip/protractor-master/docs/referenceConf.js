/**
 * The reference configuration has moved. Please refer to /lib/config.ts
 */
