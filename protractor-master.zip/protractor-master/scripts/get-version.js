console.log(require('../package.json').version);
